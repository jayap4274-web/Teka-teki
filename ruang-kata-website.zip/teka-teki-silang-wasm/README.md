# Ruang Kata — Teka-Teki Silang

Website teka-teki silang responsif dengan tiga tingkat kesulitan. Mesin pemeriksaan huruf dan perhitungan skor ditulis dalam bahasa C lalu dikompilasi menjadi WebAssembly (`engine.wasm`). Antarmuka menggunakan HTML, CSS, dan JavaScript.

## Isi proyek

- `index.html` — struktur halaman.
- `style.css` — desain responsif.
- `app.js` — interaksi papan, petunjuk, timer, bantuan, dan skor.
- `engine.c` — kode sumber mesin permainan dalam C.
- `engine.wasm` — hasil kompilasi C untuk browser.
- `easy.json`, `medium.json`, `hard.json` — data teka-teki tiap tingkat.

## Menjalankan di komputer

Jangan membuka `index.html` langsung dengan skema `file://`, karena browser dapat memblokir pemuatan JSON dan WebAssembly. Jalankan server lokal dari folder proyek:

```bash
python -m http.server 8000
```

Kemudian buka `http://localhost:8000`.

## Publikasi gratis dengan GitHub Pages

1. Buat repositori baru di GitHub.
2. Unggah seluruh isi folder proyek ini ke direktori utama repositori (bukan hanya `index.html`).
3. Buka **Settings → Pages**.
4. Pada **Build and deployment**, pilih **Deploy from a branch**.
5. Pilih branch `main` dan folder `/ (root)`, lalu tekan **Save**.
6. Setelah proses publikasi selesai, GitHub akan memberikan URL website yang bisa dibagikan.

Alternatif: unggah seluruh folder ke Netlify atau Cloudflare Pages sebagai situs statis.

## Mengompilasi ulang mesin C ke WebAssembly

Dengan Clang yang mendukung target `wasm32` dan `wasm-ld`:

```bash
clang --target=wasm32 -O2 -nostdlib engine.c -o engine.wasm \
  -Wl,--no-entry \
  -Wl,--export=check_char \
  -Wl,--export=score_for \
  -Wl,--export=is_complete \
  -Wl,--export-memory \
  -Wl,--initial-memory=131072 \
  -Wl,--max-memory=131072
```

## Catatan

- Tidak memerlukan database atau server backend; semua permainan berjalan di browser.
- Koneksi internet diperlukan untuk memuat font Google yang digunakan. Jika offline, website tetap berfungsi dengan font cadangan sistem.
- Skor dasar maksimal 1000; setiap bantuan mengurangi 50 poin.
