/* Crossword validation engine: compiled to WebAssembly. */
__attribute__((export_name("check_char")))
int check_char(int expected, int entered) {
    if (entered >= 'a' && entered <= 'z') entered -= 32;
    if (expected >= 'a' && expected <= 'z') expected -= 32;
    return expected == entered;
}

__attribute__((export_name("score_for")))
int score_for(int correct, int total, int hints) {
    if (total <= 0) return 0;
    int score = (correct * 1000) / total;
    score -= hints * 50;
    return score < 0 ? 0 : score;
}

__attribute__((export_name("is_complete")))
int is_complete(int correct, int total) {
    return total > 0 && correct == total;
}
