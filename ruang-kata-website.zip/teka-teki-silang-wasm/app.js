const $ = (s) => document.querySelector(s);
const state = { level:'easy', puzzle:null, cells:[], entries:[], active:null, direction:'across', hints:0, seconds:0, interval:null, wasm:null, started:false };
const files = { easy:'easy.json', medium:'medium.json', hard:'hard.json' };
const levelNames = {easy:'Pemula',medium:'Menengah',hard:'Mahir'};

async function initEngine(){
  try {
    const response = await fetch('engine.wasm');
    if(!response.ok) throw new Error('WASM tidak ditemukan');
    const {instance} = await WebAssembly.instantiate(await response.arrayBuffer());
    state.wasm = instance.exports;
    $('#engineStatus').classList.add('ready');
    $('#engineStatus').innerHTML = '<i></i> Mesin C / WebAssembly aktif';
  } catch(err) {
    $('#engineStatus').innerHTML = '<i></i> Mode cadangan aktif';
    console.warn('Mesin WebAssembly tidak dapat dimuat:',err);
  }
}
function isCorrect(expected, entered){
  if(state.wasm) return !!state.wasm.check_char(expected.charCodeAt(0),entered.charCodeAt(0));
  return expected.toUpperCase()===entered.toUpperCase();
}
function startClock(){
  if(state.interval) clearInterval(state.interval);
  state.seconds=0; state.started=true; updateClock();
  state.interval=setInterval(()=>{state.seconds++;updateClock()},1000);
}
function updateClock(){const m=String(Math.floor(state.seconds/60)).padStart(2,'0'),s=String(state.seconds%60).padStart(2,'0');$('#timer').textContent=`${m}:${s}`;}
function stopClock(){if(state.interval)clearInterval(state.interval);state.interval=null;}
function makeGrid(puzzle){
  const cells=Array.from({length:puzzle.rows},()=>Array.from({length:puzzle.cols},()=>({letter:'',entries:[],number:null})));
  puzzle.entries.forEach((e,idx)=>{
    for(let i=0;i<e.answer.length;i++){
      const r=e.row+(e.dir==='down'?i:0),c=e.col+(e.dir==='across'?i:0),cell=cells[r][c];
      cell.letter=e.answer[i];cell.entries.push(idx);
      if(i===0)cell.number=e.number;
    }
  });
  return cells;
}
async function loadLevel(level){
  state.level=level; state.hints=0; state.direction='across'; state.active=null;
  stopClock();
  try {const res=await fetch(files[level]);if(!res.ok)throw new Error('Data puzzle tidak ditemukan');state.puzzle=await res.json();}
  catch(e){$('#message').textContent='Gagal memuat teka-teki. Jalankan website melalui server lokal atau hosting.';return;}
  state.entries=state.puzzle.entries.map(e=>({...e,done:false}));
  state.cells=makeGrid(state.puzzle); state.started=false;
  $('#levelTitle').textContent=`Tingkat ${levelNames[level]}`;
  document.querySelectorAll('.level').forEach(b=>b.classList.toggle('active',b.dataset.level===level));
  $('#hintCount').textContent='0'; $('#score').textContent='0'; $('#message').textContent='Pilih kotak pada papan, lalu jawab petunjuknya.';
  renderBoard();renderClues();updateProgress();updateSelectedLabel();
  $('#timer').textContent='00:00';
}
function renderBoard(){
  const board=$('#board');board.innerHTML='';board.style.gridTemplateColumns=`repeat(${state.puzzle.cols},auto)`;
  state.cells.forEach((row,r)=>row.forEach((cell,c)=>{
    const el=document.createElement('div');el.className='cell'+(!cell.letter?' block':'');el.dataset.r=r;el.dataset.c=c;
    if(cell.letter){
      if(cell.number){const num=document.createElement('span');num.className='number';num.textContent=cell.number;el.append(num);}
      const input=document.createElement('input');input.maxLength=1;input.autocomplete='off';input.autocapitalize='characters';input.spellcheck=false;input.setAttribute('aria-label',`Baris ${r+1}, kolom ${c+1}`);input.dataset.r=r;input.dataset.c=c;
      input.addEventListener('focus',()=>selectCell(r,c));
      input.addEventListener('input',e=>{const v=e.target.value.toUpperCase().replace(/[^A-Z]/g,'').slice(-1);e.target.value=v;if(v){startClockIfNeeded();moveNext();}updateProgress();updateScore();checkCompletion();});
      input.addEventListener('keydown',handleKey);
      el.append(input);
    }
    board.append(el);
  }));
  const first=state.entries.find(e=>e.dir==='across')||state.entries[0];if(first)selectCell(first.row,first.col,first.dir);
}
function startClockIfNeeded(){if(!state.started)startClock();}
function currentEntry(){if(!state.active)return null;return state.entries.find(e=>e.dir===state.direction&&contains(e,state.active.r,state.active.c))||state.entries.find(e=>contains(e,state.active.r,state.active.c));}
function contains(e,r,c){return e.dir==='across'?r===e.row&&c>=e.col&&c<e.col+e.answer.length:c===e.col&&r>=e.row&&r<e.row+e.answer.length;}
function selectCell(r,c,dir){
  if(!state.cells[r]?.[c]?.letter)return;
  state.active={r,c};
  const possible=state.cells[r][c].entries.map(i=>state.entries[i]);
  if(dir)state.direction=dir;else if(!possible.some(e=>e.dir===state.direction)&&possible.length)state.direction=possible[0].dir;
  updateHighlights();renderClues();updateSelectedLabel();
  const input=document.querySelector(`input[data-r="${r}"][data-c="${c}"]`);if(input&&document.activeElement!==input)input.focus({preventScroll:true});
}
function toggleDirectionIfPossible(r,c){const poss=state.cells[r][c].entries.map(i=>state.entries[i]);if(poss.length>1)state.direction=state.direction==='across'?'down':'across';}
function updateHighlights(){
  document.querySelectorAll('.cell').forEach(el=>el.classList.remove('selected','highlight'));
  const e=currentEntry();if(e){for(let i=0;i<e.answer.length;i++){const r=e.row+(e.dir==='down'?i:0),c=e.col+(e.dir==='across'?i:0);document.querySelector(`.cell[data-r="${r}"][data-c="${c}"]`)?.classList.add('highlight');}}
  if(state.active)document.querySelector(`.cell[data-r="${state.active.r}"][data-c="${state.active.c}"]`)?.classList.add('selected');
  document.querySelectorAll('.clue-tab').forEach(b=>b.classList.toggle('active',b.dataset.dir===state.direction));
}
function renderClues(){
  const list=$('#clueList');list.innerHTML='';
  state.entries.filter(e=>e.dir===state.direction).sort((a,b)=>a.number-b.number).forEach(e=>{
    const idx=state.entries.indexOf(e),btn=document.createElement('button');btn.className='clue-item'+(e===currentEntry()?' active':'')+(e.done?' completed':'');
    btn.innerHTML=`<span class="clue-num">${e.number}</span><span>${escapeHtml(e.clue)}${e.done?' ✓':''}</span>`;
    btn.addEventListener('click',()=>selectCell(e.row,e.col,e.dir));list.append(btn);
  });
}
function escapeHtml(s){return s.replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));}
function updateSelectedLabel(){const e=currentEntry();$('#selectedLabel').textContent=e?`${e.number} · ${e.dir==='across'?'Mendatar':'Menurun'} · ${e.answer.length} huruf`:'Pilih salah satu kotak untuk mulai.';}
function getInput(r,c){return document.querySelector(`input[data-r="${r}"][data-c="${c}"]`);}
function moveNext(){const e=currentEntry();if(!e)return;const cells=[];for(let i=0;i<e.answer.length;i++)cells.push({r:e.row+(e.dir==='down'?i:0),c:e.col+(e.dir==='across'?i:0)});const idx=cells.findIndex(p=>p.r===state.active.r&&p.c===state.active.c);const next=cells.slice(idx+1).find(p=>!getInput(p.r,p.c).value);if(next)selectCell(next.r,next.c,e.dir);else{const after=cells[idx+1];if(after)selectCell(after.r,after.c,e.dir);}}
function handleKey(e){const r=+e.target.dataset.r,c=+e.target.dataset.c;let nr=r,nc=c;
  if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.key)){e.preventDefault();if(e.key==='ArrowUp'){nr--;state.direction='down'}if(e.key==='ArrowDown'){nr++;state.direction='down'}if(e.key==='ArrowLeft'){nc--;state.direction='across'}if(e.key==='ArrowRight'){nc++;state.direction='across'}if(state.cells[nr]?.[nc]?.letter)selectCell(nr,nc,state.direction);}
  else if(e.key==='Backspace'&&!e.target.value){e.preventDefault();const e2=currentEntry();if(!e2)return;const dr=e2.dir==='down'?-1:0,dc=e2.dir==='across'?-1:0;nr=r+dr;nc=c+dc;if(state.cells[nr]?.[nc]?.letter){selectCell(nr,nc,e2.dir);getInput(nr,nc).value='';updateProgress();updateScore();}}
  else if(e.key==='Tab'){e.preventDefault();const entries=state.entries.filter(x=>x.dir===state.direction),idx=entries.indexOf(currentEntry()),next=entries[(idx+1)%entries.length];selectCell(next.row,next.col,next.dir);}
}
function updateProgress(){let filled=0,total=0;state.cells.forEach(row=>row.forEach(cell=>{if(cell.letter)total++;}));document.querySelectorAll('.cell input').forEach(i=>{if(i.value)filled++});$('#progress').textContent=`${filled} / ${total} huruf terisi`;}
function updateScore(){const total=state.cells.flat().filter(c=>c.letter).length;let correct=0;state.cells.forEach((row,r)=>row.forEach((cell,c)=>{if(cell.letter&&getInput(r,c)?.value&&isCorrect(cell.letter,getInput(r,c).value))correct++;}));const score=state.wasm?state.wasm.score_for(correct,total,state.hints):Math.max(0,Math.floor(correct*1000/total)-state.hints*50);$('#score').textContent=score;return {correct,total,score};}
function checkAnswers(){let right=0,total=0;state.cells.forEach((row,r)=>row.forEach((cell,c)=>{if(!cell.letter)return;total++;const input=getInput(r,c),el=input.parentElement;el.classList.remove('correct','wrong');if(input.value){if(isCorrect(cell.letter,input.value)){el.classList.add('correct');right++;}else el.classList.add('wrong');}}));
  state.entries.forEach(e=>{e.done=true;for(let i=0;i<e.answer.length;i++){const r=e.row+(e.dir==='down'?i:0),c=e.col+(e.dir==='across'?i:0);if(!isCorrect(e.answer[i],getInput(r,c).value||'')){e.done=false;break;}}});renderClues();const result=updateScore();$('#message').textContent=`${right} dari ${total} huruf sudah benar.`;return result;
}
function useHint(){const e=currentEntry();if(!e){$('#message').textContent='Pilih petunjuk terlebih dahulu.';return;}const positions=[];for(let i=0;i<e.answer.length;i++){const r=e.row+(e.dir==='down'?i:0),c=e.col+(e.dir==='across'?i:0);if(!isCorrect(e.answer[i],getInput(r,c).value||''))positions.push({r,c,i});}if(!positions.length){$('#message').textContent='Kata ini sudah benar.';return;}const p=positions[0],input=getInput(p.r,p.c);input.value=e.answer[p.i];input.parentElement.classList.add('revealed');state.hints++;$('#hintCount').textContent=state.hints;startClockIfNeeded();updateProgress();updateScore();$('#message').textContent='Satu huruf dibuka. Skor berkurang 50 poin.';moveNext();checkCompletion();}
function checkCompletion(){const result=updateScore();const complete=state.wasm?state.wasm.is_complete(result.correct,result.total):result.correct===result.total;if(complete&&result.total>0){stopClock();showResult(true,result);}}
function showResult(force=false,result=updateScore()){$('#resultTitle').textContent=force?'Sempurna!':'Permainan dihentikan';$('#resultText').textContent=force?`Semua huruf terjawab dalam ${$('#timer').textContent}. Kamu berhasil menuntaskan tingkat ${levelNames[state.level]}.`:`Kamu mengisi ${result.correct} dari ${result.total} huruf. Masih ada jawaban yang bisa diperbaiki.`;$('#resultScore').textContent=result.score;$('#resultModal').hidden=false;}
function resetLevel(){loadLevel(state.level);}

document.querySelectorAll('.level').forEach(b=>b.addEventListener('click',()=>loadLevel(b.dataset.level)));
document.querySelectorAll('.clue-tab').forEach(b=>b.addEventListener('click',()=>{state.direction=b.dataset.dir;const e=state.entries.find(x=>x.dir===state.direction);if(e)selectCell(e.row,e.col,e.dir);else renderClues();}));
$('#checkBtn').addEventListener('click',()=>{const r=checkAnswers();$('#message').textContent=`Pemeriksaan selesai: ${r.correct} dari ${r.total} huruf benar.`;checkCompletion();});
$('#hintBtn').addEventListener('click',useHint);$('#resetBtn').addEventListener('click',resetLevel);
$('#finishBtn').addEventListener('click',()=>{stopClock();const r=checkAnswers();showResult(false,r);});
$('#closeModal').addEventListener('click',()=>$('#resultModal').hidden=true);$('#playAgain').addEventListener('click',()=>{$('#resultModal').hidden=true;resetLevel();});
$('#helpBtn').addEventListener('click',()=>$('#helpModal').hidden=false);$('#closeHelp').addEventListener('click',()=>$('#helpModal').hidden=true);$('#gotIt').addEventListener('click',()=>$('#helpModal').hidden=true);
$('#year').textContent=new Date().getFullYear();
(async()=>{await initEngine();await loadLevel('easy');})();
